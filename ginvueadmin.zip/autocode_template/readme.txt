代码解压后把fe的api文件内容粘贴进前端api文件夹下并修改为自己想要的名字即可

后端代码解压后同理，放到自己想要的 mvc对应路径 并且到 initRouter中注册自动生成的路由 到registerTable中注册自动生成的model

项目github:"https://github.com/piexlmax/gin-vue-admin"

希望大家给个star多多鼓励

暂时不保存大家生成的结构体 只为方便一次性使用